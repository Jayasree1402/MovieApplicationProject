import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn : boolean = false;
  Token: string='';
constructor(private http:HttpClient){}
userUrl:string="http://localhost:9000/api/v2/register/image";
postUserDetails(body:any):Observable<any>{
  console.log("from service user",body);
  return this.http.post<any>(this.userUrl,body)
}

loginUrl:string="http://localhost:9000/api/v1/login";
loginUser(body:any):Observable<any>{
  this.isLoggedIn=true;
  console.log("calling service",body);
  return this.http.post<any>(this.loginUrl,body,{responseType:'text' as 'json'});
}
}
