import { Component } from '@angular/core';
import { MoviesService } from '../service/movies.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-movie-card',
  templateUrl: './movie-card.component.html',
  styleUrls: ['./movie-card.component.css']
})
export class MovieCardComponent {

  movies:any[]=[];
  constructor(private moviesService:MoviesService,private router:Router){
  }

  favoriteItems: string[] = [];
  isLoggedIn : boolean = false;
  addFavorite(movie:any) {
    console.log("from method",movie);
    this.moviesService.addFavourite(movie).subscribe(data=>{
        console.log("data",data);
        alert("added to fav list");
    })
  
  }



  ngOnInit():void{
    console.log("calling service");
    this.moviesService.getAllMovies().subscribe({next:(data:any)=>{
      this.movies=data.results;
      console.log("movie details",this.movies);
    },
  error:(error: any)=>{
    alert("fetching movie data");
    console.error("error msg",error);
  }})
  }

}
