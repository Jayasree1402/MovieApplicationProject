import { Component } from '@angular/core';
import { MoviesService } from '../service/movies.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-top-rated',
  templateUrl: './top-rated.component.html',
  styleUrls: ['./top-rated.component.css']
})
export class TopRatedComponent {
  movies:any[]=[];
  // displayedMovies: any[] = []; // Array to store the top 10 movies for display
 
 
   constructor(private moviesService:MoviesService,private router:Router){
   }
 
   favoriteItems: string[] = [];
 
   addFavorite(movie:any) {
    console.log("from method",movie);
    this.moviesService.addFavourite(movie).subscribe(data=>{
        console.log("data",data);
        alert("added to fav list");
    })
   }
 
 
 
   ngOnInit():void{
     console.log("calling service");
     this.moviesService.getTopRated().subscribe({next:(data:any)=>{
       this.movies=data.results;
       console.log("movie details", this.movies);
 
       // Display only the top 10 movies
      // this.displayedMovies = this.movies.slice(0, 10);
     },
   error:(error: any)=>{
     alert("Errror while fetching movie data");
     console.error("error msg",error);
   }})
   }
 
   
 
}
